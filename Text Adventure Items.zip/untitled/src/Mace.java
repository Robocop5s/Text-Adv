public class Mace extends Weapon{

    public Mace() {
        super("Mace", "A spiky ball that swings, does more damage than a Sword.", 30,40);
    }
}
