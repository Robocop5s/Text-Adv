public class Arrow extends Weapon{

    public Arrow() {
        super("Arrow", "A ranged weapon than can be fatal depending on the archer", 2, 10);
    }
}
