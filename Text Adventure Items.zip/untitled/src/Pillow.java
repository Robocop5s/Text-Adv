public class Pillow  extends Weapon{

    public Pillow() {
        super("Pillow", "A super soft pillow that puts enemies to sleep, never underestimate its power", 60,100);
    }
}
