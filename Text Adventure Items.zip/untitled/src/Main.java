public class Main {
    public static void main(String[] args) {
        //Item i1 = new Item("item name", "item desc", 10);
        //Item i2 = new Item("item name2", "item desc2", 11);

        Gold goldbar = new Gold(100);

        //Weapon weapon = new Weapon("super weapon", "super 2 weapon", 10, 45);
        //weapon.setDamage(45);
        //int dvalue = weapon.getDamage();

        Sword superSword = new Sword();
        Pillow softPillow = new Pillow();
        Mace spikyMace = new Mace();
        Arrow sharpArrow = new Arrow();
    }
}