public class Sword extends Weapon{

    public Sword() {
        super("Sword", "A Sword that is a tad bit rusty, much more dangerous than a dagger.", 10, 20);
    }
}
